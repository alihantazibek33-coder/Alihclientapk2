package com.craftmenu.app;

import android.animation.ValueAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

public class FloatingService extends Service {

    private static final String CH = "craft_overlay";

    private WindowManager wm;
    private SharedPreferences sp;
    private final Handler h = new Handler(Looper.getMainLooper());
    private String ver = "";

    private TextView bubble;
    private WindowManager.LayoutParams bp;
    private int bubbleSize;

    private LinearLayout panel;
    private WindowManager.LayoutParams pp;
    private TextView[] tabBtns;

    // Секундомер / таймер күйі
    private boolean swRun;
    private long swStart, swAcc;
    private boolean cdRun;
    private long cdEnd, cdLeft;
    private TextView swText, cdText;

    // Калькулятор күйі
    private String cur = "0", op = "";
    private double acc;
    private boolean fresh = true;
    private TextView calcDisp;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        sp = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startAsForeground();
        if (intent != null && intent.getStringExtra("ver") != null) {
            ver = intent.getStringExtra("ver");
        }
        if (bubble == null) createBubble();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        closePanel();
        if (bubble != null) {
            try {
                wm.removeView(bubble);
            } catch (Exception ignored) {
            }
            bubble = null;
        }
        h.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    // ---------------------------------------------------------------- helpers

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    private int sw() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    private int sh() {
        return getResources().getDisplayMetrics().heightPixels;
    }

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private void startAsForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder nb;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH, "Craft Menu",
                    NotificationManager.IMPORTANCE_LOW));
            nb = new Notification.Builder(this, CH);
        } else {
            nb = new Notification.Builder(this);
        }
        Notification n = nb.setContentTitle("Craft Menu")
                .setContentText("Домалақ батырма жұмыс істеп тұр")
                .setSmallIcon(android.R.drawable.ic_menu_manage)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
    }

    // ----------------------------------------------------------------- bubble

    private void createBubble() {
        bubbleSize = dp(58);
        bubble = new TextView(this);
        bubble.setText("⛏");
        bubble.setTextSize(26);
        bubble.setGravity(Gravity.CENTER);
        bubble.setTextColor(Color.WHITE);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF8FE05A, 0xFF3A8A1E});
        g.setShape(GradientDrawable.OVAL);
        g.setStroke(dp(3), 0xFF1D4A0C);
        bubble.setBackground(g);

        bp = new WindowManager.LayoutParams(bubbleSize, bubbleSize, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        bp.gravity = Gravity.TOP | Gravity.START;
        bp.x = sp.getInt("bx", 0);
        bp.y = sp.getInt("by", dp(200));

        bubble.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = bp.x;
                        sy = bp.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        moved = false;
                        v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(80).start();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - tx;
                        float dy = e.getRawY() - ty;
                        if (!moved && Math.hypot(dx, dy) > dp(6)) {
                            moved = true;
                            closePanel();
                        }
                        if (moved) {
                            bp.x = Math.max(0, Math.min((int) (sx + dx), sw() - bubbleSize));
                            bp.y = Math.max(0, Math.min((int) (sy + dy), sh() - bubbleSize));
                            try {
                                wm.updateViewLayout(bubble, bp);
                            } catch (Exception ignored) {
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.animate().scaleX(1f).scaleY(1f).setDuration(80).start();
                        if (!moved && e.getActionMasked() == MotionEvent.ACTION_UP) {
                            togglePanel();
                        } else if (moved) {
                            snapToEdge();
                        }
                        return true;
                }
                return false;
            }
        });
        wm.addView(bubble, bp);
    }

    private void snapToEdge() {
        final int target = (bp.x + bubbleSize / 2 < sw() / 2) ? 0 : sw() - bubbleSize;
        sp.edit().putInt("bx", target).putInt("by", bp.y).apply();
        ValueAnimator a = ValueAnimator.ofInt(bp.x, target);
        a.setDuration(180);
        a.addUpdateListener(va -> {
            if (bubble == null) return;
            bp.x = (int) va.getAnimatedValue();
            try {
                wm.updateViewLayout(bubble, bp);
            } catch (Exception ignored) {
            }
        });
        a.start();
    }

    // ------------------------------------------------------------------ panel

    private void togglePanel() {
        if (panel != null) closePanel();
        else openPanel();
    }

    private int contentH() {
        return Math.min(dp(290), sh() - dp(190));
    }

    private void openPanel() {
        int pw = Math.min(dp(310), sw() - dp(12));

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(Ui.block(this, Ui.PANEL));
        panel.setPadding(dp(10), dp(10), dp(10), dp(10));

        // Тақырып
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = Ui.label(this, "CRAFT MENU", 16, 0xFF7ED957);
        head.addView(title);
        TextView v = Ui.label(this, "  " + ver, 12, 0xFFFFD84A);
        head.addView(v, new LinearLayout.LayoutParams(0, -2, 1));
        TextView close = Ui.button(this, "✕", Ui.RED, 13);
        close.setPadding(dp(10), dp(2), dp(10), dp(2));
        close.setOnClickListener(x -> closePanel());
        head.addView(close);
        panel.addView(head);

        // Табтар
        final FrameLayout content = new FrameLayout(this);
        content.setBackground(Ui.block(this, Ui.FIELD));
        content.setPadding(dp(8), dp(8), dp(8), dp(8));

        String[] names = {"ЖАЗБА", "КООРД", "ТАЙМЕР", "КАЛЬК"};
        LinearLayout tabs = new LinearLayout(this);
        tabBtns = new TextView[names.length];
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            tabBtns[i] = Ui.button(this, names[i], Ui.STONE, 11);
            tabBtns[i].setPadding(dp(2), dp(7), dp(2), dp(7));
            tabBtns[i].setOnClickListener(x -> showTab(content, idx));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
            lp.setMargins(dp(2), dp(8), dp(2), dp(8));
            tabs.addView(tabBtns[i], lp);
        }
        panel.addView(tabs);
        panel.addView(content, new LinearLayout.LayoutParams(-1, contentH()));

        TextView exit = Ui.button(this, "⏻  ДОМАЛАҚТЫ ЖАБУ", Ui.RED, 12);
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(-1, -2);
        elp.topMargin = dp(8);
        exit.setOnClickListener(x -> stopSelf());
        panel.addView(exit, elp);

        showTab(content, sp.getInt("tab", 0));

        pp = new WindowManager.LayoutParams(pw, WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        pp.gravity = Gravity.TOP | Gravity.START;
        pp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN;
        placePanel();
        wm.addView(panel, pp);

        panel.setAlpha(0f);
        panel.setScaleX(0.85f);
        panel.setScaleY(0.85f);
        panel.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(160).start();
    }

    private void placePanel() {
        int gap = dp(8);
        int ph = contentH() + dp(150);
        boolean bubbleLeft = bp.x + bubbleSize / 2 < sw() / 2;
        int x = bubbleLeft ? bp.x + bubbleSize + gap : bp.x - pp.width - gap;
        pp.x = Math.max(dp(6), Math.min(x, sw() - pp.width - dp(6)));
        pp.y = Math.max(dp(6), Math.min(bp.y, sh() - ph - dp(6)));
    }

    private void closePanel() {
        if (panel == null) return;
        releaseFocus();
        try {
            wm.removeView(panel);
        } catch (Exception ignored) {
        }
        panel = null;
        swText = null;
        cdText = null;
        calcDisp = null;
    }

    private void showTab(FrameLayout content, int i) {
        releaseFocus();
        sp.edit().putInt("tab", i).apply();
        content.removeAllViews();
        swText = null;
        cdText = null;
        calcDisp = null;
        for (int k = 0; k < tabBtns.length; k++) {
            tabBtns[k].setTextColor(k == i ? 0xFFFFD84A : Color.WHITE);
        }
        View view;
        switch (i) {
            case 1:
                view = coordsView();
                break;
            case 2:
                view = timerView();
                break;
            case 3:
                view = calcView();
                break;
            default:
                view = notesView();
        }
        content.addView(view, new FrameLayout.LayoutParams(-1, -1));
    }

    // Клавиатура керек болғанда ғана терезені "focusable" етеміз,
    // әйтпесе ойын фокусты жоғалтып, паузаға түсуі мүмкін.
    private void setPanelFocusable(boolean f) {
        if (panel == null || pp == null) return;
        if (f) pp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        else pp.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        try {
            wm.updateViewLayout(panel, pp);
        } catch (Exception ignored) {
        }
    }

    private void releaseFocus() {
        if (panel == null) return;
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(panel.getWindowToken(), 0);
        setPanelFocusable(false);
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFF777777);
        e.setTextColor(Color.WHITE);
        e.setTextSize(13);
        e.setTypeface(Typeface.MONOSPACE);
        e.setBackground(Ui.block(this, Ui.FIELD));
        e.setPadding(dp(8), dp(6), dp(8), dp(6));
        e.setOnTouchListener((view, ev) -> {
            if (ev.getAction() == MotionEvent.ACTION_DOWN
                    && (pp.flags & WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) != 0) {
                setPanelFocusable(true);
                view.post(() -> {
                    view.requestFocus();
                    ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                            .showSoftInput(view, InputMethodManager.SHOW_IMPLICIT);
                });
            }
            return false;
        });
        e.setOnFocusChangeListener((view, has) -> {
            if (!has) setPanelFocusable(false);
        });
        return e;
    }

    private LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout.LayoutParams lp(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    // -------------------------------------------------------------- tab: notes

    private View notesView() {
        EditText e = field("Жазба...");
        e.setText(sp.getString("notes", ""));
        e.setGravity(Gravity.TOP | Gravity.START);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        e.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                sp.edit().putString("notes", s.toString()).apply();
            }
        });
        return e;
    }

    // ------------------------------------------------------------ tab: coords

    private EditText numField(String hint) {
        EditText e = field(hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        e.setSingleLine(true);
        return e;
    }

    private View coordsView() {
        LinearLayout col = vbox();
        final EditText name = field("Атауы (үй, шахта...)");
        name.setSingleLine(true);
        col.addView(name, lp(-1, -2, 0));

        final EditText x = numField("X"), y = numField("Y"), z = numField("Z");
        LinearLayout row = new LinearLayout(this);
        LinearLayout.LayoutParams rl = lp(0, -2, 1);
        rl.setMargins(0, dp(6), dp(4), dp(6));
        row.addView(x, rl);
        row.addView(y, rl);
        LinearLayout.LayoutParams rl2 = lp(0, -2, 1);
        rl2.setMargins(0, dp(6), 0, dp(6));
        row.addView(z, rl2);
        col.addView(row);

        TextView save = Ui.button(this, "+ САҚТАУ", Ui.GRASS, 12);
        col.addView(save, lp(-1, -2, 0));

        final LinearLayout list = vbox();
        ScrollView sv = new ScrollView(this);
        sv.addView(list);
        LinearLayout.LayoutParams slp = lp(-1, 0, 1);
        slp.topMargin = dp(8);
        col.addView(sv, slp);

        final Runnable[] refresh = new Runnable[1];
        refresh[0] = () -> {
            list.removeAllViews();
            try {
                JSONArray a = new JSONArray(sp.getString("coords", "[]"));
                for (int i = 0; i < a.length(); i++) {
                    final int idx = i;
                    JSONObject o = a.getJSONObject(i);
                    LinearLayout r = new LinearLayout(this);
                    r.setGravity(Gravity.CENTER_VERTICAL);
                    r.setBackground(Ui.block(this, Ui.PANEL));
                    r.setPadding(dp(8), dp(4), dp(6), dp(4));
                    TextView t = Ui.label(this, o.optString("n") + "\n"
                            + o.optString("x") + "  " + o.optString("y") + "  " + o.optString("z"),
                            12, Color.WHITE);
                    r.addView(t, lp(0, -2, 1));
                    TextView del = Ui.button(this, "✕", Ui.RED, 12);
                    del.setPadding(dp(8), dp(2), dp(8), dp(2));
                    del.setOnClickListener(vw -> {
                        try {
                            JSONArray b = new JSONArray(sp.getString("coords", "[]"));
                            b.remove(idx);
                            sp.edit().putString("coords", b.toString()).apply();
                        } catch (Exception ignored) {
                        }
                        refresh[0].run();
                    });
                    r.addView(del);
                    LinearLayout.LayoutParams ll = lp(-1, -2, 0);
                    ll.bottomMargin = dp(4);
                    list.addView(r, ll);
                }
            } catch (Exception ignored) {
            }
        };

        save.setOnClickListener(vw -> {
            String xs = x.getText().toString().trim();
            String ys = y.getText().toString().trim();
            String zs = z.getText().toString().trim();
            if (xs.isEmpty() && ys.isEmpty() && zs.isEmpty()) {
                Toast.makeText(this, "Координата енгіз", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                String n = name.getText().toString().trim();
                JSONObject o = new JSONObject();
                o.put("n", n.isEmpty() ? "Орын" : n);
                o.put("x", xs);
                o.put("y", ys);
                o.put("z", zs);
                JSONArray a = new JSONArray(sp.getString("coords", "[]"));
                a.put(o);
                sp.edit().putString("coords", a.toString()).apply();
            } catch (Exception ignored) {
            }
            name.setText("");
            x.setText("");
            y.setText("");
            z.setText("");
            releaseFocus();
            refresh[0].run();
        });

        refresh[0].run();
        return col;
    }

    // ------------------------------------------------------------- tab: timer

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updateTimes();
            if (swRun || cdRun) h.postDelayed(this, 100);
        }
    };

    private void updateTimes() {
        long now = SystemClock.elapsedRealtime();
        if (cdRun) {
            cdLeft = cdEnd - now;
            if (cdLeft <= 0) {
                cdRun = false;
                cdLeft = 0;
                Toast.makeText(this, "⏰ Уақыт бітті!", Toast.LENGTH_LONG).show();
            }
        }
        if (swText != null) swText.setText(fmtSw(swAcc + (swRun ? now - swStart : 0)));
        if (cdText != null) cdText.setText(fmtCd(cdLeft));
    }

    private String fmtSw(long ms) {
        long t = ms / 100;
        return String.format(Locale.US, "%02d:%02d.%d", t / 600, (t / 10) % 60, t % 10);
    }

    private String fmtCd(long ms) {
        long s = (Math.max(ms, 0) + 999) / 1000;
        return String.format(Locale.US, "%02d:%02d", s / 60, s % 60);
    }

    private void startCountdown(long ms) {
        cdLeft = ms;
        cdEnd = SystemClock.elapsedRealtime() + ms;
        cdRun = true;
        h.removeCallbacks(tick);
        h.post(tick);
    }

    private View timerView() {
        LinearLayout col = vbox();
        col.setGravity(Gravity.CENTER_HORIZONTAL);

        col.addView(Ui.label(this, "СЕКУНДОМЕР", 12, 0xFFFFD84A));
        swText = Ui.label(this, "", 30, Color.WHITE);
        swText.setGravity(Gravity.CENTER);
        col.addView(swText, lp(-1, -2, 0));

        LinearLayout r1 = new LinearLayout(this);
        final TextView startBtn = Ui.button(this, swRun ? "СТОП" : "СТАРТ", Ui.GRASS, 13);
        TextView resetBtn = Ui.button(this, "ҚАЙТА", Ui.STONE, 13);
        LinearLayout.LayoutParams a = lp(0, -2, 1);
        a.setMargins(0, dp(6), dp(4), dp(10));
        LinearLayout.LayoutParams b = lp(0, -2, 1);
        b.setMargins(dp(4), dp(6), 0, dp(10));
        r1.addView(startBtn, a);
        r1.addView(resetBtn, b);
        col.addView(r1, lp(-1, -2, 0));

        startBtn.setOnClickListener(vw -> {
            long now = SystemClock.elapsedRealtime();
            if (swRun) {
                swAcc += now - swStart;
                swRun = false;
                startBtn.setText("СТАРТ");
            } else {
                swStart = now;
                swRun = true;
                startBtn.setText("СТОП");
                h.removeCallbacks(tick);
                h.post(tick);
            }
            updateTimes();
        });
        resetBtn.setOnClickListener(vw -> {
            swRun = false;
            swAcc = 0;
            startBtn.setText("СТАРТ");
            updateTimes();
        });

        col.addView(Ui.label(this, "ТАЙМЕР (кері санау)", 12, 0xFFFFD84A));
        cdText = Ui.label(this, "", 28, Color.WHITE);
        cdText.setGravity(Gravity.CENTER);
        col.addView(cdText, lp(-1, -2, 0));

        LinearLayout r2 = new LinearLayout(this);
        long[] mins = {1, 5, 10};
        for (final long m : mins) {
            TextView p = Ui.button(this, m + "м", Ui.DIRT, 12);
            p.setOnClickListener(vw -> startCountdown(m * 60000L));
            LinearLayout.LayoutParams l = lp(0, -2, 1);
            l.setMargins(dp(2), dp(6), dp(2), 0);
            r2.addView(p, l);
        }
        TextView stopCd = Ui.button(this, "СТОП", Ui.RED, 12);
        stopCd.setOnClickListener(vw -> {
            cdRun = false;
            cdLeft = 0;
            updateTimes();
        });
        LinearLayout.LayoutParams l2 = lp(0, -2, 1);
        l2.setMargins(dp(2), dp(6), dp(2), 0);
        r2.addView(stopCd, l2);
        col.addView(r2, lp(-1, -2, 0));

        updateTimes();
        if (swRun || cdRun) {
            h.removeCallbacks(tick);
            h.post(tick);
        }
        return col;
    }

    // -------------------------------------------------------- tab: calculator

    private View calcView() {
        LinearLayout col = vbox();
        calcDisp = Ui.label(this, cur, 24, Color.WHITE);
        calcDisp.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        calcDisp.setSingleLine(true);
        calcDisp.setBackground(Ui.block(this, Ui.PANEL));
        calcDisp.setPadding(dp(10), 0, dp(10), 0);
        col.addView(calcDisp, lp(-1, dp(46), 0));

        String[][] rows = {
                {"7", "8", "9", "÷"},
                {"4", "5", "6", "×"},
                {"1", "2", "3", "−"},
                {"0", ".", "=", "+"},
                {"C", "⌫"}
        };
        for (String[] r : rows) {
            LinearLayout row = new LinearLayout(this);
            for (final String k : r) {
                int[] pal = Ui.STONE;
                if (k.equals("÷") || k.equals("×") || k.equals("−") || k.equals("+")) pal = Ui.DIRT;
                if (k.equals("=")) pal = Ui.GRASS;
                if (k.equals("C")) pal = Ui.RED;
                TextView btn = Ui.button(this, k, pal, 18);
                btn.setOnClickListener(vw -> press(k));
                LinearLayout.LayoutParams l = lp(0, -1, 1);
                l.setMargins(dp(2), dp(2), dp(2), dp(2));
                row.addView(btn, l);
            }
            LinearLayout.LayoutParams rl = lp(-1, 0, 1);
            col.addView(row, rl);
        }
        return col;
    }

    private void press(String k) {
        switch (k) {
            case "C":
                cur = "0";
                acc = 0;
                op = "";
                fresh = true;
                break;
            case "⌫":
                if (!fresh && cur.length() > 1) cur = cur.substring(0, cur.length() - 1);
                else {
                    cur = "0";
                    fresh = true;
                }
                break;
            case "+":
            case "−":
            case "×":
            case "÷":
                if (!op.isEmpty() && !fresh) {
                    acc = apply(acc, op, parse(cur));
                    cur = fmt(acc);
                } else {
                    acc = parse(cur);
                }
                op = k;
                fresh = true;
                break;
            case "=":
                if (!op.isEmpty()) {
                    acc = apply(acc, op, parse(cur));
                    cur = fmt(acc);
                    op = "";
                    fresh = true;
                }
                break;
            default:
                if (fresh) {
                    cur = k.equals(".") ? "0." : k;
                    fresh = false;
                } else {
                    if (k.equals(".") && cur.contains(".")) break;
                    if (cur.equals("0") && !k.equals(".")) cur = k;
                    else if (cur.length() < 14) cur += k;
                }
        }
        if (calcDisp != null) calcDisp.setText(cur);
    }

    private double parse(String s) {
        try {
            return Double.parseDouble(s);
        } catch (Exception e) {
            return 0;
        }
    }

    private double apply(double a, String o, double b) {
        switch (o) {
            case "+":
                return a + b;
            case "−":
                return a - b;
            case "×":
                return a * b;
            default:
                return a / b;
        }
    }

    private String fmt(double d) {
        if (Double.isNaN(d) || Double.isInfinite(d)) return "Қате";
        if (d == Math.rint(d) && Math.abs(d) < 1e15) return String.valueOf((long) d);
        String s = String.format(Locale.US, "%.8f", d);
        return s.replaceAll("0+$", "").replaceAll("\\.$", "");
    }
}

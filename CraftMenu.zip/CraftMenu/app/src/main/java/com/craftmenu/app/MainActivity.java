package com.craftmenu.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    static final String PREFS = "craft";
    static final String MC_PKG = "com.mojang.minecraftpe";
    static final String[] VERSIONS = {
            "1.21.50", "1.21.40", "1.21.30", "1.21.0",
            "1.20.80", "1.20.50", "1.20.10", "1.19.80",
            "1.19.50", "1.18.12", "1.17.41", "1.16.221"
    };

    private SharedPreferences sp;
    private int sel;
    private LinearLayout chipRow;
    private TextView selLabel, permText, permBtn;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        sel = Math.min(sp.getInt("ver", 0), VERSIONS.length - 1);
        getWindow().setStatusBarColor(0xFF4FA9F0);
        getWindow().setNavigationBarColor(0xFF573517);
        setContentView(buildUi());
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPerm();
    }

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    private View buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF4FA9F0, 0xFFBFE6FF}));

        // Бұлттар
        cloud(root, 24, 90, 90);
        cloud(root, 220, 150, 70);
        cloud(root, 120, 330, 60);

        // Жер: шөп + топырақ
        LinearLayout ground = new LinearLayout(this);
        ground.setOrientation(LinearLayout.VERTICAL);
        View grass = new View(this);
        grass.setBackgroundColor(0xFF5DA130);
        ground.addView(grass, new LinearLayout.LayoutParams(-1, dp(22)));
        View grassEdge = new View(this);
        grassEdge.setBackgroundColor(0xFF3A6E1E);
        ground.addView(grassEdge, new LinearLayout.LayoutParams(-1, dp(5)));
        View dirt = new View(this);
        dirt.setBackgroundColor(0xFF8B5A2B);
        ground.addView(dirt, new LinearLayout.LayoutParams(-1, -1));
        root.addView(ground, new FrameLayout.LayoutParams(-1, dp(100), Gravity.BOTTOM));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(20), dp(44), dp(20), dp(110));
        scroll.addView(col, new ViewGroup.LayoutParams(-1, -2));
        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));

        // Тақырып
        TextView title = Ui.label(this, "CRAFT MENU", 36, Color.WHITE);
        title.setShadowLayer(1f, 5f, 5f, 0xFF234A12);
        title.setGravity(Gravity.CENTER);
        col.addView(title);
        TextView sub = Ui.label(this, "Майнкрафт іске қосқыш", 14, 0xFF1B3A57);
        sub.setGravity(Gravity.CENTER);
        col.addView(sub);

        // Версия картасы
        LinearLayout card = card();
        card.addView(Ui.label(this, "ВЕРСИЯНЫ ТАҢДА", 13, 0xFFFFD84A));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        chipRow = new LinearLayout(this);
        chipRow.setPadding(0, dp(10), 0, dp(10));
        hs.addView(chipRow);
        card.addView(hs);
        selLabel = Ui.label(this, "", 13, Color.WHITE);
        card.addView(selLabel);
        col.addView(card, cardLp(24));
        renderChips();

        // Рұқсат картасы
        LinearLayout perm = card();
        permText = Ui.label(this, "", 13, Color.WHITE);
        perm.addView(permText);
        permBtn = Ui.button(this, "РҰҚСАТ БЕРУ", Ui.DIRT, 14);
        permBtn.setOnClickListener(v -> openOverlaySettings());
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-1, -2);
        plp.topMargin = dp(10);
        perm.addView(permBtn, plp);
        col.addView(perm, cardLp(14));

        // ОЙНАУ
        TextView play = Ui.button(this, "▶  ОЙНАУ", Ui.GRASS, 24);
        play.setOnClickListener(v -> play());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(68));
        lp.topMargin = dp(24);
        col.addView(play, lp);

        TextView stop = Ui.button(this, "ДОМАЛАҚТЫ ӨШІРУ", Ui.STONE, 13);
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, FloatingService.class));
            Toast.makeText(this, "Домалақ өшірілді", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2);
        slp.topMargin = dp(12);
        col.addView(stop, slp);

        return root;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(Ui.block(this, Ui.PANEL));
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        return c;
    }

    private LinearLayout.LayoutParams cardLp(int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(topDp);
        return lp;
    }

    private void cloud(FrameLayout root, int x, int y, int w) {
        View big = new View(this);
        big.setBackgroundColor(0xCCFFFFFF);
        FrameLayout.LayoutParams a = new FrameLayout.LayoutParams(dp(w), dp(w / 4f));
        a.leftMargin = dp(x);
        a.topMargin = dp(y);
        root.addView(big, a);
        View top = new View(this);
        top.setBackgroundColor(0xCCFFFFFF);
        FrameLayout.LayoutParams b = new FrameLayout.LayoutParams(dp(w / 2f), dp(w / 5f));
        b.leftMargin = dp(x + w / 4f);
        b.topMargin = dp(y - w / 5f);
        root.addView(top, b);
    }

    private void renderChips() {
        chipRow.removeAllViews();
        for (int i = 0; i < VERSIONS.length; i++) {
            final int idx = i;
            TextView chip = Ui.button(this, VERSIONS[i], i == sel ? Ui.GRASS : Ui.STONE, 14);
            chip.setOnClickListener(v -> {
                sel = idx;
                sp.edit().putInt("ver", sel).apply();
                renderChips();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = dp(8);
            chipRow.addView(chip, lp);
        }
        selLabel.setText("Таңдалған: Minecraft " + VERSIONS[sel]);
    }

    private void refreshPerm() {
        boolean ok = Settings.canDrawOverlays(this);
        permText.setText(ok ? "Домалақ батырма рұқсаты: ✔ бар" : "Домалақ батырма рұқсаты: ✖ жоқ");
        permBtn.setVisibility(ok ? View.GONE : View.VISIBLE);
    }

    private void openOverlaySettings() {
        startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())));
    }

    private void play() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Алдымен рұқсат бер", Toast.LENGTH_SHORT).show();
            openOverlaySettings();
            return;
        }
        Intent mc = getPackageManager().getLaunchIntentForPackage(MC_PKG);
        if (mc == null) {
            Toast.makeText(this, "Minecraft орнатылмаған", Toast.LENGTH_LONG).show();
            return;
        }
        Intent svc = new Intent(this, FloatingService.class).putExtra("ver", VERSIONS[sel]);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc);
        else startService(svc);
        startActivity(mc);
    }
}

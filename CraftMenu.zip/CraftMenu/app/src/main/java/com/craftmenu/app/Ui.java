package com.craftmenu.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Gravity;
import android.widget.TextView;

/** Minecraft стиліндегі "блок" түймелер мен панельдер. */
final class Ui {
    // {негізгі түс, ашық жиек (сол-жоғары), қара жиек (оң-төмен)}
    static final int[] STONE = {0xFF7A7A7A, 0xFFB4B4B4, 0xFF474747};
    static final int[] GRASS = {0xFF5DA130, 0xFF8FD65A, 0xFF37691C};
    static final int[] DIRT = {0xFF8B5A2B, 0xFFB98348, 0xFF573517};
    static final int[] RED = {0xFFC0392B, 0xFFE8786B, 0xFF7B241C};
    static final int[] PANEL = {0xFF2B2B2B, 0xFF505050, 0xFF101010};
    static final int[] FIELD = {0xFF1A1A1A, 0xFF0A0A0A, 0xFF4A4A4A};

    private Ui() {}

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable rect(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        return g;
    }

    static int darken(int color, float f) {
        return Color.rgb((int) (Color.red(color) * f), (int) (Color.green(color) * f), (int) (Color.blue(color) * f));
    }

    /** Пиксельді бевел (қабырғасы бар блок) фоны. */
    static Drawable block(Context c, int[] p) {
        LayerDrawable ld = new LayerDrawable(new Drawable[]{
                rect(Color.BLACK), rect(p[2]), rect(p[1]), rect(p[0])});
        int b = dp(c, 2);
        ld.setLayerInset(1, b, b, b, b);
        ld.setLayerInset(2, b, b, 2 * b, 2 * b);
        ld.setLayerInset(3, 2 * b, 2 * b, 2 * b, 2 * b);
        return ld;
    }

    static TextView button(Context c, String text, int[] pal, float sp) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(sp);
        t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        t.setShadowLayer(1f, 2f, 2f, 0xAA000000);
        t.setClickable(true);
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed},
                block(c, new int[]{darken(pal[0], 0.85f), pal[2], pal[1]}));
        s.addState(new int[]{}, block(c, pal));
        t.setBackground(s);
        t.setPadding(dp(c, 10), dp(c, 8), dp(c, 10), dp(c, 8));
        return t;
    }

    static TextView label(Context c, String text, float sp, int color) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        return t;
    }
}
